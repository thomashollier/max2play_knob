#!/usr/bin/python -u



import requests, time

#
# For testing
# Created two communicating serial ports like this:
# socat -d -d pty,raw,echo=0,crnl pty,raw,echo=0,crnl
# Created temp values, will come from pinging LMS
#

originalPlayerName = "testPlayer"
originalPowerState = True
originalPlayState = True
originalVolume = 50

serverIP = "192.168.11.3:9000"
playerMAC = "b8:27:eb:17:25:b1"
volumeStep = 5




def getPlayerName():
        return originalPlayerName

def getPowerState(playerName):
        return originalPowerState

def getPlayState(playerName):
        return originalPlayState

def getVolume(playerName):
        return originalVolume

def togglePlayState(playerName, playState):
        url = "http://%s/status.html" % serverIP
        params = {"p0":"pause", "player":playerMAC}
        r = requests.get(url, params)
        print(r.request.url)
        if playState:
                return False
        else:
                return True

def changeVolume(playerName, playerVolume, v):
        url = "http://%s/status.html" % serverIP
        params = {"p0":"mixer", "p1":"volume", "p2":"%s%s"%("+" if v>0 else "",v), "player":playerMAC}
        r = requests.get(url, params)
        print(r.request.url)
        return playerVolume + v


playerName = getPlayerName()
powerState = getPowerState(playerName)
playState = getPlayState(playerName)
playerVolume = getVolume(playerName)



import evdev, time

devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
device = False
while not device:
	try:
		device = [x for x in devices if x.name == "Adafruit Trinket HID Combo"][0]
	except:
		print("no hid combo found")
		time.sleep(1)

print("continue")

evdev.device.KbdInfo(repeat=.3,delay=100100)

for event in device.read_loop():
	if event.type == evdev.ecodes.EV_KEY and event.value == 1:
		if event.code == evdev.ecodes.KEY_VOLUMEDOWN:
        		print("down")
        		changeVolume(playerName, playerVolume, -volumeStep)
		elif event.code == evdev.ecodes.KEY_VOLUMEUP:
       		 	print("up")
        		changeVolume(playerName, playerVolume, volumeStep)
		elif event.code == evdev.ecodes.KEY_MUTE:
        		print("mute")
        		togglePlayState(playerName, playState)

