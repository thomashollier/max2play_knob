#!/usr/bin/python

import evdev

devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
device = [x for x in devices if x.name == "Adafruit Trinket HID Combo"][0]

for event in device.read_loop():
	if event.code == evdev.ecodes.KEY_VOLUMEDOWN:
		print("down")
	elif event.code == evdev.ecodes.KEY_VOLUMEUP:
		print("up")
	elif event.code == evdev.ecodes.KEY_MUTE:
		print("mute")



