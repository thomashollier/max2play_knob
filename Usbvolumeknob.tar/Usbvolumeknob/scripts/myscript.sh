#!/bin/bash

echo "Custom Bash-Script"

exit 0