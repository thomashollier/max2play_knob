#!/bin/bash

# Path to current Directory
CURRENTDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

echo "Install-Script"

echo $@

echo "Update sources"
sudo apt-get update
echo "Done"

echo "Install pip"
apt-get install python-pip
echo "Done"

echo "Install evdev"
pip install evdev
echo "Done"

echo "Install requests"
pip install requests
echo "Done"

echo "Creating systemd usbvolumeknob.service file"
cat > /lib/systemd/system/usbvolumeknob.service << EOF
[Unit]
Description=USB Rotary Knob service
After=multi-user.target

[Service]
Type=simple
ExecStart=/var/www/max2play/application/plugins/FuckThis/scripts/captureAndInstruct.py

[Install]
WantedBy=multi-user.target

EOF

echo "Registering, enabling and starting systemd usbvolumeknob.service"
systemctl daemon-reload
sudo systemctl enable usbvolumeknob.service
sudo systemctl start usbvolumeknob.service

echo "finished"
exit 0
